import java.util.ArrayList;
import java.util.List;

/**
 * PayrollManager.java
 * Manages a list of employees. Handles add, update, delete, search.
 * Demonstrates: ArrayList, Methods, Loops
 */
public class PayrollManager {

    private ArrayList<Employee> employees;

    // ── Constructor ──────────────────────────────────────────────
    public PayrollManager() {
        this.employees = new ArrayList<>();
    }

    // ── Add Employee ─────────────────────────────────────────────
    public void addEmployee(Employee emp) {
        employees.add(emp);
    }

    // ── Update Employee ──────────────────────────────────────────
    public void updateEmployee(int index, Employee emp) {
        if (index >= 0 && index < employees.size()) {
            employees.set(index, emp);
        }
    }

    // ── Delete Employee ──────────────────────────────────────────
    public void deleteEmployee(int index) {
        if (index >= 0 && index < employees.size()) {
            employees.remove(index);
        }
    }

    // ── Get Employee ─────────────────────────────────────────────
    public Employee getEmployee(int index) {
        if (index >= 0 && index < employees.size()) {
            return employees.get(index);
        }
        return null;
    }

    // ── Get All ──────────────────────────────────────────────────
    public List<Employee> getAllEmployees() {
        return employees;
    }

    // ── Count ────────────────────────────────────────────────────
    public int getCount() {
        return employees.size();
    }

    // ── Search by Name or ID ─────────────────────────────────────
    public int findByName(String name) {
        for (int i = 0; i < employees.size(); i++) {
            if (employees.get(i).getName().equalsIgnoreCase(name)) return i;
        }
        return -1;
    }

    // ── Aggregate Stats ──────────────────────────────────────────
    public double getTotalGross() {
        double total = 0;
        for (Employee e : employees) total += e.getGrossSalary();
        return total;
    }

    public double getTotalDeductions() {
        double total = 0;
        for (Employee e : employees) total += e.getTotalDeductions();
        return total;
    }

    public double getTotalNet() {
        double total = 0;
        for (Employee e : employees) total += e.getNetSalary();
        return total;
    }

    public double getHighestSalary() {
        if (employees.isEmpty()) return 0;
        double max = employees.get(0).getNetSalary();
        for (Employee e : employees) if (e.getNetSalary() > max) max = e.getNetSalary();
        return max;
    }

    public double getLowestSalary() {
        if (employees.isEmpty()) return 0;
        double min = employees.get(0).getNetSalary();
        for (Employee e : employees) if (e.getNetSalary() < min) min = e.getNetSalary();
        return min;
    }

    public double getAverageSalary() {
        if (employees.isEmpty()) return 0;
        return getTotalNet() / employees.size();
    }
}
